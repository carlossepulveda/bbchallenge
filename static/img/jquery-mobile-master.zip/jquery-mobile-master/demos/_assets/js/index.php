<?php
$type = 'text/javascript';
$files = array(
	'jqm-demos.js',
	'view-source.js',
	'h2widget.js'
);

require_once('../../../combine.php');
