<?php
$type = 'text/css';
$files = array(
	'../../../LICENSE-INFO.txt',
	'jquery.mobile.css'
);
$base = dirname(__FILE__);
