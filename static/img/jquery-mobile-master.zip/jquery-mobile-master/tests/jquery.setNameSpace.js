//set namespace for unit test markp
jQuery( document ).bind( "mobileinit", function(){
	jQuery.mobile.ns = "nstest-";
	$.support.inlineSVG = $.noop;
});