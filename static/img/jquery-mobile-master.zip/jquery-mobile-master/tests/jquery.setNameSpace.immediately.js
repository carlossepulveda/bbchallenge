//set namespace for unit test markup
jQuery.mobile.ns = "nstest-";
$.support.inlineSVG = $.noop;
