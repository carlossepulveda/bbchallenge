var IndexView = Backbone.View.extend({

		initialize : function() {
		}
});